package com.listazakupow;

public class ObjectGrocery {

    int id;
    String groceryPosition;
    String groceryAmount;
    String groceryPrice;
    String groceryBought;

    public ObjectGrocery () {}

}

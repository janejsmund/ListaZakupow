package com.listazakupow;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

public class ListActivity extends Activity {

    Button addGrocery;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        addGrocery = (Button) findViewById(R.id.addGrocery);
        addGrocery.setOnClickListener(new OnClickListenerAddGrocery());

        readRecords();
    }

    public void readRecords() {

        LinearLayout linearLayoutRecords = (LinearLayout) findViewById(R.id.linearLayoutRecords);
        linearLayoutRecords.removeAllViews();

        List<ObjectGrocery> groceries = new TableControllerGroceries(this).read();

        if (groceries.size() > 0) {

            for (ObjectGrocery object : groceries) {

                int id = object.id;
                String groceryPosition = object.groceryPosition;
                String groceryAmount = object.groceryAmount;

                String textViewContents = groceryPosition + " - " + groceryAmount;

                TextView textViewStudentItem= new TextView(this);
                textViewStudentItem.setPadding(0, 10, 0, 10);
                textViewStudentItem.setText(textViewContents);
                textViewStudentItem.setTag(Integer.toString(id));

                linearLayoutRecords.addView(textViewStudentItem);
            }

        }

        else {

            TextView locationItem = new TextView(this);
            locationItem.setPadding(8, 8, 8, 8);
            locationItem.setText("Lista jest pusta.");

            linearLayoutRecords.addView(locationItem);
        }

    }
}

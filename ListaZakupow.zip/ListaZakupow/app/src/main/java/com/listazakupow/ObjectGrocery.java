package com.listazakupow;

public class ObjectGrocery {

    int id;
    String groceryPosition;
    String groceryAmount;

    public ObjectGrocery () {}

}
